#!/bin/bash
allnames="XOM GOOG AAPL IBM JNJ HOG BAC JPM MSFT MMM SPY DIA"
echo "Total number of sell orders of each stock"
for name in $allnames
do
    if [ ! -d $name ]
    then
        mkdir $name
        cd $name
        touch \<$name\>_20130124.txt
        cd ..
        grep -E "\s$name\s" S20130124_subset.txt > ./$name/\<$name\>_20130124.txt
    fi
    echo -n "$name "
    grep -E '^[AF]\s[0-9]+\s[0-9]+\sS' ./$name/\<$name\>_20130124.txt | wc -l
done