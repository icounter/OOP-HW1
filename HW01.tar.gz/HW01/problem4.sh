#!/bin/bash
for name in $allnames
do
echo -n "$name " >> stock_activity_rank.txt
wc -l < ./$name/\<$name\>_20130124.txt >> stock_activity_rank.txt
done
echo -n "The most active stock of the list is: "
sort -k2 -n -r stock_activity_rank.txt | head -n 1 | cut -d' ' -f1
rm stock_activity_rank.txt #remove the txt file that was used to sort the most active stock